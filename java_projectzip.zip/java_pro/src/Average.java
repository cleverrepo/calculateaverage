import java.util.Scanner;

public class Average {
    public static void main(String[] args) {
        //simple java project on how to calculate you average
        Scanner scanner=new Scanner(System.in);//we want to get the user input by using scanner class
        int firstScore;
        int secondScore;
        int thirdScore = 0;

        float average;
        System.out.println("enter the firstScore:: ");
        firstScore=scanner.nextInt();
        System.out.println("enter the secondScore:: ");
        secondScore=scanner.nextInt();
        System.out.println("enter the thirdScore1:: ");
        thirdScore=scanner.nextInt();

        average=(firstScore+secondScore+thirdScore)/3;

        if(average>=90){
            System.out.println("you average is "+average);

            System.out.println("A");
        }else if(average>=80){
            System.out.println("you average is "+average);
            System.out.println("B");
        } else if (average>=70) {
            System.out.println("you average is "+average);
            System.out.println("C");
        } else if (average>=60) {
            System.out.println("you average is "+average);
            System.out.println("D ");
        }else if(average>=50) {
            System.out.println("you average is "+average);

        }else {
            System.out.println("you average is "+average);
            System.out.println("F ");


        }



    }
}
